#clear all
rm(list=ls(all=T))
# first, 
set the working directory to the one with the burrow data
setwd("C:/Users/Danaes Documents/aUNI/Research Masters/Data/dataloggers data/GDS body temps")
gds<-read.table("13-Nov-13 0548_data-logger_Z_B47.txt",h=T)
names(gds)
tb<-gds$Temp
activity<-rep(0,length(tb))
for (i in 29:length(tb)-1){
  if ((tb[i]+tb[i+1])/2 > 1.1*min(tb[(i-8):(i-28)], na.rm = TRUE)){
    activity[i]=1}
}
color <- rep("black",length(tb))
for (i in 1:length(color)){
  if (activity[i] == 1 & activity[i+1] ==1){
    color[i] <- "royalblue1"}
}

xaxis=c(ISOdatetime(2013,10,18,0,0,0),ISOdatetime(2013,11,13,0,0,0))
xlabs=c("Oct 18","Nov 13")
datetime <- seq(c(ISOdatetime(2013,10,18,12,0,0)),by=900,length.out=2472)
plot(datetime,tb,type="n",ylim=c(15,45),xlab="Date",ylab="Temp (C)",cex.lab=2,axes=FALSE)
axis(side=2,xaxp=c(15,45,5),cex.axis=1.5)
axis(side=1,at=xaxis,labels=xlabs,cex.axis=1.5)
box()
title(main="B47 body temps")
segments(x0=datetime[1:2471],y0=tb[1:2471],x1=datetime[2:2472],y1=tb[2:2472],col=color)
legend(ISOdatetime(2013,10,30,0,0,0),47,c("Tb while inactive","Tb while active"),col=c("black","royalblue1"),border=NA,cex=1,lty=1,lwd=1,seg.len=0.3,bty="n",y.intersp=0.3,x.intersp=0.3)

day<-seq(1,27,by=1)
day<-rep(day,times=1,length.out=NA,each=96)
day<-day[49:2520]
time<-seq(0,23.75,by=0.25)
time<-rep(time,times=27,length.out=NA,each=1)
time<-time[49:2520]

gdsactivity<-data.frame(gds,activity,day,time)
activesubset <- subset(gdsactivity,activity>=1, select=c(day,time))
plot(activesubset$time,activesubset$day,ylim=c(0,24),type="n",xlab="Day of Year",ylab="Time of Day",cex.lab=3,axes=FALSE)
axis(side=2,at=c(0,4,8,12,16,20,24),labels=c("0:00","8:00","12:00","16:00","18:00","21:00","24:00"))
axis(side=1,at=c(1,27)labels=c("Oct 18","Nov 13"))
box()
title(main="B47 activity",cex.main=3)
points